<?php
define('DB_HOST', 'sql103.infinityfree.com');
define('DB_USER', 'if0_39179312');
define('DB_PASS', 'lxb5bkSPHL');
define('DB_NAME', 'if0_39179312_portfolio');
?>